#'accuracy
#'@param conf_matrix yigejuzhen
#'@return a value of accuracy
#'@examples
#'mat <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)
#'function(mat)
accuracy <- function(conf_matrix) {
  # 计算分类模型的准确率
  accuracy_value <- sum(diag(conf_matrix)) / sum(conf_matrix)
  return(accuracy_value)
}
