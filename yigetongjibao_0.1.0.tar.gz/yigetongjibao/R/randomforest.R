#' Train a Random Forest Model
#'
#' This function trains a random forest model using the randomForest package.
#'
#' @param X A data frame or matrix containing the predictor variables.
#' @param y A vector containing the response variable.
#' @param ntree An integer specifying the number of trees in the forest.
#' @return A random forest model.
#' @export
train_rf_model <- function(X, y, ntree = 100) {
  # Load the randomForest package function using the :: operator
  model <- randomForest::randomForest(x = X, y = y, ntree = ntree)
  return(model)
}
