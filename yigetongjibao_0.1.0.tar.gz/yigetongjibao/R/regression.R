#' Gradient Descent for Linear Regression
#'
#' This function implements the gradient descent algorithm to optimize the parameters
#' (weights and bias) of a simple linear regression model. The objective is to minimize
#' the Mean Squared Error (MSE) between the predicted values and actual values.
#'
#' @param X A numeric vector of predictor values (independent variable).
#' @param y A numeric vector of target values (dependent variable).
#' @param learning_rate A numeric value specifying the learning rate for gradient descent.
#' @param iterations An integer specifying the number of iterations for gradient descent.
#'
#' @return A list containing the optimized values of weights (`w`) and bias (`b`),
#'         as well as the history of the loss function (`loss_history`) during training.
#'
#' @examples
#' # Example usage:
#' set.seed(42)
#' X <- rnorm(100)
#' y <- 3 * X + 5 + rnorm(100)  # Linear relationship with noise
#' result <- gradient_descent(X, y, learning_rate = 0.01, iterations = 1000)
#' cat("Optimized w:", result$w, "Optimized b:", result$b, "\n")
#' plot(result$loss_history, type = "l", col = "blue", main = "Loss Curve")
#'
#' @export
gradient_descent <- function(X, y, learning_rate = 0.01, iterations = 1000) {
  # 初始化参数 w 和 b
  w <- 0  # 权重
  b <- 0  # 偏置

  n <- length(y)  # 样本大小

  # 记录损失值，用于监控训练过程
  loss_history <- numeric(iterations)

  for (i in 1:iterations) {
    # 计算模型的预测值
    y_pred <- w * X + b

    # 计算梯度
    dw <- -2/n * sum(X * (y - y_pred))  # w的梯度
    db <- -2/n * sum(y - y_pred)        # b的梯度

    # 更新参数
    w <- w - learning_rate * dw
    b <- b - learning_rate * db

    # 计算并保存当前的损失值（均方误差）
    loss <- mean((y - y_pred)^2)
    loss_history[i] <- loss

    # 每100次迭代输出一次损失值
    if (i %% 100 == 0) {
      cat("Iteration:", i, " Loss:", loss, "\n")
    }
  }

  return(list(w = w, b = b, loss_history = loss_history))
}
sigmoid <- function(z) {
  1 / (1 + exp(-z))
}
#' Logistic Regression using Gradient Descent
#'
#' This function implements logistic regression using gradient descent to minimize the
#' binary cross-entropy loss.
#'
#' @param X A numeric matrix or data frame where each row is a training sample and each
#'          column is a feature.
#' @param y A numeric vector containing the true binary labels (0 or 1).
#' @param learning_rate A numeric value specifying the learning rate for gradient descent.
#' @param iterations An integer specifying the number of iterations for gradient descent.
#' @param threshold A numeric value specifying the decision boundary for classification (default is 0.5).
#'
#' @return A list containing the optimized weights (`w`), bias (`b`), and the history of the
#'         loss function (`loss_history`) during training.
#'
#' @examples
#' set.seed(42)
#' X <- matrix(c(1, 2, 1, 3, 2, 4), ncol = 2)
#' y <- c(0, 1, 1)
#' result <- logistic_regression(X, y, learning_rate = 0.1, iterations = 1000)
#' cat("Optimized w:", result$w, "Optimized b:", result$b, "\n")
#' plot(result$loss_history, type = "l", col = "blue", main = "Loss Curve")
#'
#' @export
logistic_regression <- function(X, y, learning_rate = 0.01, iterations = 1000, threshold = 0.5) {
  # Initialize weights and bias
  w <- rep(0, ncol(X))  # Weights initialized to zero
  b <- 0                # Bias initialized to zero

  n <- length(y)  # Number of samples
  m <- ncol(X)    # Number of features

  # Store the loss at each iteration
  loss_history <- numeric(iterations)

  for (i in 1:iterations) {
    # Calculate predictions using the logistic function
    z <- X %*% w + b  # Linear combination
    y_pred <- sigmoid(z)  # Apply sigmoid

    # Compute the gradient of the loss with respect to w and b
    dw <- -1/n * colSums((y - y_pred) * X)
    db <- -1/n * sum(y - y_pred)

    # Update parameters
    w <- w - learning_rate * dw
    b <- b - learning_rate * db

    # Compute and save the loss at each iteration
    loss <- -1/n * sum(y * log(y_pred) + (1 - y) * log(1 - y_pred))
    loss_history[i] <- loss

    # Print progress every 100 iterations
    if (i %% 100 == 0) {
      cat("Iteration:", i, " Loss:", loss, "\n")
    }
  }

  return(list(w = w, b = b, loss_history = loss_history))
}
